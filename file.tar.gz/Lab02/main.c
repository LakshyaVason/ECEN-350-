extern long long int test();
extern long long int lab02b();
extern void lab02c(long long int a);
int main(void)
{
	test();
	lab02b();
	lab02c(226);
    return 0;
}
